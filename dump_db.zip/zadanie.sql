-- Adminer 4.8.1 MySQL 10.7.3-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `clients` (`id`, `name`, `email`, `phone`, `address`, `city`, `postal_code`, `country`) VALUES
(2,	'Firma Nowak',	'kontakt@nowak.pl',	'987654321',	'ul. Przykładowa 2',	'Kraków',	'30-002',	'Polska'),
(3,	'Firma Wiśniewski',	'kontakt@wisniewski.pl',	'456789123',	'ul. Przykładowa 3',	'Łódź',	'90-003',	'Polska'),
(4,	'Firma Wójcik',	'kontakt@wojcik.pl',	'789123456',	'ul. Przykładowa 4',	'Wrocław',	'50-004',	'Polska'),
(5,	'Firma Kamiński',	'kontakt@kaminski.pl',	'321654987',	'ul. Przykładowa 5',	'Poznań',	'60-005',	'Polska'),
(6,	'Firma Lewandowska',	'kontakt@lewandowska.pl',	'654987321',	'ul. Przykładowa 6',	'Gdańsk',	'80-006',	'Polska'),
(7,	'Firma Zieliński',	'kontakt@zielinski.pl',	'987321654',	'ul. Przykładowa 7',	'Szczecin',	'70-007',	'Polska'),
(8,	'Firma Szymańska',	'kontakt@szymanska.pl',	'123789456',	'ul. Przykładowa 8',	'Bydgoszcz',	'85-008',	'Polska'),
(9,	'Firma Woźniak',	'kontakt@wozniak.pl',	'789456123',	'ul. Przykładowa 9',	'Lublin',	'20-009',	'Polska'),
(10,	'Firma Dąbrowska',	'kontakt@dabrowska.pl',	'456123789',	'ul. Przykładowa 10',	'Katowice',	'40-010',	'Polska'),
(11,	'Firma Kozłowski',	'kontakt@kozlowski.pl',	'321987654',	'ul. Przykładowa 11',	'Białystok',	'15-011',	'Polska'),
(12,	'Firma Jankowska',	'kontakt@jankowska.pl',	'654321987',	'ul. Przykładowa 12',	'Gdynia',	'81-012',	'Polska'),
(13,	'Firma Mazur',	'kontakt@mazur.pl',	'987654123',	'ul. Przykładowa 13',	'Częstochowa',	'42-013',	'Polska'),
(14,	'Firma Kwiatkowska',	'kontakt@kwiatkowska.pl',	'123456987',	'ul. Przykładowa 14',	'Radom',	'26-014',	'Polska'),
(15,	'Firma Piotrowski',	'kontakt@piotrowski.pl',	'789123654',	'ul. Przykładowa 15',	'Sosnowiec',	'41-015',	'Polska');

DROP TABLE IF EXISTS `clients_meta`;
CREATE TABLE `clients_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `meta_key` varchar(50) NOT NULL,
  `meta_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `clients_meta_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `clients_meta` (`id`, `parent_id`, `meta_key`, `meta_value`) VALUES
(3,	2,	'contacts',	'a:2:{s:17:\"new_1742932062487\";a:3:{s:4:\"name\";s:4:\"adaw\";s:5:\"email\";s:15:\"bukowski@mda.pl\";s:5:\"phone\";s:9:\"123145655\";}s:17:\"new_1742932330687\";a:3:{s:4:\"name\";s:4:\"test\";s:5:\"email\";s:20:\"akbukowska@gmail.com\";s:5:\"phone\";s:9:\"666135645\";}}');

DROP TABLE IF EXISTS `connections_clients_consultants`;
CREATE TABLE `connections_clients_consultants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `consultant_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `client_id` (`client_id`),
  KEY `consultant_id` (`consultant_id`),
  CONSTRAINT `connections_clients_consultants_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `connections_clients_consultants_ibfk_2` FOREIGN KEY (`consultant_id`) REFERENCES `consultants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `connections_clients_consultants` (`id`, `client_id`, `consultant_id`) VALUES
(8,	2,	1),
(13,	2,	2),
(14,	2,	7),
(15,	11,	1);

DROP TABLE IF EXISTS `connections_clients_packages`;
CREATE TABLE `connections_clients_packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `created` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `package_id` (`package_id`),
  KEY `client_id` (`client_id`),
  CONSTRAINT `connections_clients_packages_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `connections_clients_packages_ibfk_2` FOREIGN KEY (`package_id`) REFERENCES `packages_lib` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `connections_clients_packages` (`id`, `client_id`, `package_id`, `created`) VALUES
(5,	2,	2,	NULL),
(7,	11,	4,	NULL);

DROP TABLE IF EXISTS `consultants`;
CREATE TABLE `consultants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `consultants` (`id`, `first_name`, `last_name`, `email`, `phone`) VALUES
(1,	'Jan Marta',	'Kowalski',	'jan.kowalski@example.com',	'123456777'),
(2,	'Anna',	'Nowak',	'anna.nowak@example.com',	'987654321'),
(3,	'Piotr',	'Wiśniewski',	'piotr.wisniewski@example.com',	'456789123'),
(4,	'Katarzyna',	'Wójcik',	'katarzyna.wojcik@example.com',	'789123456'),
(5,	'Tomasz',	'Kamiński',	'tomasz.kaminski@example.com',	'321654987'),
(6,	'Agnieszka',	'Lewandowska',	'agnieszka.lewandowska@example.com',	'654987321'),
(7,	'Michał',	'Zieliński',	'michal.zielinski@example.com',	'987321654');

DROP TABLE IF EXISTS `consultants_meta`;
CREATE TABLE `consultants_meta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL,
  `meta_key` varchar(50) NOT NULL,
  `meta_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `parent_id` (`parent_id`),
  CONSTRAINT `consultants_meta_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `consultants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


DROP TABLE IF EXISTS `packages_lib`;
CREATE TABLE `packages_lib` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `packages_lib` (`id`, `name`, `description`) VALUES
(1,	'Pakiet Podstawowy',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.'),
(2,	'Pakiet Standardowy',	'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.'),
(3,	'Pakiet Premium',	'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.'),
(4,	'Pakiet VIP',	'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.'),
(5,	'Pakiet Ekskluzywny',	'Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis et commodo pharetra, est eros bibendum elit, nec luctus magna felis sollicitudin mauris.');

-- 2025-03-27 07:00:54
